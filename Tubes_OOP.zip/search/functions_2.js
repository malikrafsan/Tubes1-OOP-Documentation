var searchData=
[
  ['describe_249',['describe',['../classItem.html#a309b931f6f70379decf0aa5aed231d46',1,'Item::describe()'],['../classTool.html#afea837fc7ef367d35731ccb9ac0c9eea',1,'Tool::describe()'],['../classTypedNonTool.html#a51eaaf4a809347aa1485c791b09265a8',1,'TypedNonTool::describe()']]],
  ['discardcommand_250',['discardCommand',['../classGameManager.html#a40a913aab100651d25d0ea308bf253bc',1,'GameManager']]]
];
