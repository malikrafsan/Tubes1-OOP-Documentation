var searchData=
[
  ['data_316',['data',['../classRecipeWrongFormatException.html#a4d0cf718d1ca1e19810fa3956b179c69',1,'RecipeWrongFormatException']]],
  ['durability_317',['durability',['../classTool.html#aea6e1bf7f535ee0abc422313eab4d594',1,'Tool']]]
];
