var searchData=
[
  ['_5fwhat_311',['_What',['../classFileNotFoundException.html#a61f97ec357983d70658065dbfd8d7fe8',1,'FileNotFoundException::_What()'],['../classFolderNotFoundException.html#ab9752e9b01e2e8d011f5c2227c590785',1,'FolderNotFoundException::_What()'],['../classFileCannotBeWrittenException.html#ad2f7dbb12c2910f85ca1a0a10c597d46',1,'FileCannotBeWrittenException::_What()'],['../classInvalidCommandException.html#af251c36159fe45fe67ee2e67bf21fea9',1,'InvalidCommandException::_What()'],['../classItemNotFoundException.html#a7058a4427d489d63ada7f0a64725ee99',1,'ItemNotFoundException::_What()'],['../classNonToolUseExeption.html#ac231781475c8148189eb424842273e4c',1,'NonToolUseExeption::_What()']]]
];
