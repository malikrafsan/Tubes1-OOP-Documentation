var searchData=
[
  ['ladder_2etxt_214',['LADDER.txt',['../classes_2Recipe_2tests_2input_2LADDER_8txt.html',1,'(Global Namespace)'],['../config_2recipe_2LADDER_8txt.html',1,'(Global Namespace)']]]
];
