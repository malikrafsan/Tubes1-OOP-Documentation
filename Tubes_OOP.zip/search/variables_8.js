var searchData=
[
  ['quantity_330',['quantity',['../classSlot.html#a4cca64fd37c7ff56ad356e9ec8ecb159',1,'Slot']]]
];
