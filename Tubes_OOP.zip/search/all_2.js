var searchData=
[
  ['birch_5fplank_2etxt_6',['BIRCH_PLANK.txt',['../classes_2Recipe_2tests_2input_2BIRCH__PLANK_8txt.html',1,'(Global Namespace)'],['../config_2recipe_2BIRCH__PLANK_8txt.html',1,'(Global Namespace)']]]
];
