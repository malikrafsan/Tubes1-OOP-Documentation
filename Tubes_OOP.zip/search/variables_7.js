var searchData=
[
  ['name_328',['name',['../classItem.html#af3de0f8651b58fe76c0dab1b9b83c3ba',1,'Item']]],
  ['nontools_329',['nonTools',['../classGameManager.html#a924e1f5b49303f84749d6a53ba207cf5',1,'GameManager']]]
];
