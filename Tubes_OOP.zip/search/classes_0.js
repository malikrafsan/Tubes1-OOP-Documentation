var searchData=
[
  ['_5fcommand_161',['_Command',['../struct__Command.html',1,'']]]
];
